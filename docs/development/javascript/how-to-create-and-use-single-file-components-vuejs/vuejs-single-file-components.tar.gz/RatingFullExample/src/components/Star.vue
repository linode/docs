<template>
<span><i v-bind:class="getClass()" v-on:mouseover="lightUp()" v-on:mouseleave="lightDown()" v-on:click="rate"></i></span>
</template>

<script>
import { eventBus } from '../main'

export default {
    name: 'star',
    data: function() {
        return {
            hover: false,
            active: false
        };
    },
    props: ['weight', 'enabled'],
    methods: {
        getClass: function() {
            var baseClass = 'icon-star';
            if(this.active)
            {
                baseClass += ' active'
            }

            if(this.hover)
            {
                baseClass += ' hover'
            }
            return baseClass;
        },
        lightUp: function(){
            if(this.enabled)
            {
                eventBus.$emit("lightUp", this.weight);
            }
        },
        lightDown: function(){
            if(this.enabled)
            {
                eventBus.$emit("lightDown", this.weight);
            }
        },
        rate: function(){
            if(this.enabled)
            {
                eventBus.$emit("rate", this.weight);
            }
            else
            {
                alert("Already voted");
            }
        }
    },
    created: function(){
        eventBus.$on("rate", (targetWeight) => {
            if(targetWeight >= this.weight)
            {
                this.active = true;
            }
        });
        eventBus.$on("lightUp", (targetWeight) => {
            if(targetWeight >= this.weight)
            {
                this.hover = true;
            }
        });
        eventBus.$on("lightDown", () => {
            this.hover = false;
        });
    }
}
</script>

<style scoped>
p {
    font-size: 2em;
    text-align: center;
}
</style>