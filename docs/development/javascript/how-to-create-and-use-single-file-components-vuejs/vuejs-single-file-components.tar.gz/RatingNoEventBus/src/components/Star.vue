<template>
<span><i v-bind:class="getClass()" v-on:mouseover="lightUp()" v-on:mouseleave="lightDown()" v-on:click="rate()"></i></span>
</template>

<script>

export default {
    name: 'star',
    data: function() {
        return {
            hover: false
        };
    },
    props: ['weight', 'enabled', 'currentrating'],
    methods: {
        getClass: function() {
            var baseClass = 'icon-star';

            //Adds the hover class if you're hovering over the component or you are hovering over a star with greater weight
            if(this.hover || this.currentrating >= this.weight)
            {
                baseClass += ' hover'
            }
            return baseClass;
        },
        lightUp: function(){
            //Makes sure stars are not lighting up after vote is cast
            if(this.enabled)
            {
                //Emits the lightup event with the weight as a parameter
                this.$emit("lightup", this.weight);
                //Enables hover class
                this.hover = true;
            }
        },
        lightDown: function(){
            //Makes sure stars are not lighting up after vote is cast
            if(this.enabled)
            {
                //Emits the lightdown event
                this.$emit("lightdown", this.weight);
                //Removes hover class
                this.hover = false;
            }
        },
        rate: function(){
            //Makes sure you only vote if you haven't voted yet
            if(this.enabled)
            {
                //Emits the rate event with the weight as parameter
                this.$emit("rate", this.weight);
            }
            else
            {
                alert("Already voted");
            }
        }
    }
}
</script>

<style scoped>
p {
    font-size: 2em;
    text-align: center;
}
</style>